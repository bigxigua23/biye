package com.rescue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RescueApplication {

    public static void main(String[] args) {
        SpringApplication.run(RescueApplication.class, args);
    }

}
